package com.major.connect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
